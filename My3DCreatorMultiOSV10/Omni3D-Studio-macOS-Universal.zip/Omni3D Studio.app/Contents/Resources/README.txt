Omni3D Studio for macOS
Drag to /Applications to install.
