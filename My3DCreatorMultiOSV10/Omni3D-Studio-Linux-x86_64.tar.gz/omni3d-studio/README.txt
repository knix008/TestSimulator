Omni3D Studio for Linux x86_64
Run ./omni3d-studio to start.
