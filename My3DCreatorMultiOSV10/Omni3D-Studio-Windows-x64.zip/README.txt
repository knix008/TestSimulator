Omni3D Studio for Windows x64
Run omni3d-studio.exe to start.
