Sample: a chair as OBJ + MTL + texture.
