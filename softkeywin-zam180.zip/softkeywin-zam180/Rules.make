#Note:

#	1.core board module define

MODULE=ZAM180

# Binary file output path
export DEST_PATH		:= ~/tftpboot

ifeq ($(MODULE), ZAM180)
	export ARCH					:=arm
	export PLATFORM				:=zam180
	export CROSS_COMPILE_PATH	:=/opt/toolschain/zam180/gcc-linaro-6.3.1-2017.05-x86_64_arm-linux-gnueabihf/bin
	export CROSS_COMPILE		:=$(CROSS_COMPILE_PATH)/arm-linux-gnueabihf-
	MINIGUI_ROOT_DIR			:=/opt/toolschain/zam180/minigui3012-arm-zam180
	MINIGUILIB 					:=-lpng -lfreetype -lanimate -lcommon_animates -lz -ljpeg -lminigui_procs
	
	CFLAGS	+= -DZAM180 -march=armv7-a -mfloat-abi=hard -mfpu=neon-vfpv4

endif


LD		:= $(CROSS_COMPILE)ld
CC		:= $(CROSS_COMPILE)gcc
CPP		:= $(CROSS_COMPILE)c++
AR		:= $(CROSS_COMPILE)ar
STRIP	:= $(CROSS_COMPILE)strip





